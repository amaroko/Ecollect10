create view QALL as
SELECT c.FIRSTNAME CLIENT_NAME,l.ACCNUMBER, c.CUSTNUMBER,c.emailaddress,l.INSTAMOUNT, l.DAYSINARR, s.COLOFFICER, s.REVIEWDATE, l.PRINCARREARS, l.AROCODE,l.rrocode, 
l.ORIGDATE, l.CURRENCY, l.ORIGBALANCE, s.SECTION, c.ADDRESSLINE1, c.DOB, c.CELNUMBER, c.TELNUMBER, c.NATIONID, c.STREETADDRESS, c.POSTCODE, 
l.BRANCHNAME, l.PRODUCTCODE, l.LASTCREDAMNT, s.ROUTETOSTATE, s.EXCUSE, l.LASTCREDDATE, l.NEXTREPAYDATE, l.OUSTBALANCE, m.manager, 
s.FILENO, l.INTRATEARR, l.PENALARREARS, s.DATERECEIVED, l.instamount TOTALARREARS,l.intarrears,l.debitaccruedintrate,l.debitaccruedintamount,
l.LIMITAMOUNT,l.TEMPLIMIT,l.TEMPLIMITEXPIRYDATE,
l.LIMITEXPIRYDATE,s.BRANCHSTATUS,s.CMDSTATUS, m.REGION,m.BRANCHCODE, l.kbrr, l.settleaccbal,l.settleaccno,
CASE 
   WHEN l.DAYSINARR < 31 THEN '0 - 30 Days'
  WHEN l.DAYSINARR < 61 THEN '31 - 60 Days'
  WHEN l.DAYSINARR < 91 THEN '61 - 90 Days'
  ELSE '90+ DAYS'
END AS BUCKET,
s.ACTIONDATE,
s.EXCUSE_OTHER
from loans_stage l
left join tbl_portfolio_static s on l.accnumber=s.accnumber
left join customer_stage c on l.custnumber=c.custnumber
left join branches m on m.branchcode=l.branchcode
/

